package ati.lunarmessages;

public class PostData
{
    public String postThumbUrl;
    public String postTitle;
    public String postDate;
    public String postDescription;
    public String postCategory;
}
