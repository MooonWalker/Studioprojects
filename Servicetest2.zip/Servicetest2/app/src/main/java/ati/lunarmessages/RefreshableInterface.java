package ati.lunarmessages;

public interface RefreshableInterface
{
	public void startFresh();
	public void startLoadMore();
}
