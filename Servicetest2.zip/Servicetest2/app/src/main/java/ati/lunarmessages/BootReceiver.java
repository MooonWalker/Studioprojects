package ati.lunarmessages;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.support.v4.content.WakefulBroadcastReceiver;
import android.util.Log;
import android.widget.Toast;


public class BootReceiver extends WakefulBroadcastReceiver
{
    Handler handler;
    String mes="";
    @Override
    public void onReceive(final Context context, Intent intent)
    {
        try
        {
            handler = new Handler();
            mes = "Bootreceiver";
            handler.post(new Runnable()
            {
                public void run()
                {
                    Toast.makeText(context, mes, Toast.LENGTH_SHORT).show();
                }
            });
            Log.i(Config.TAG, mes);
        }
        catch(Exception e)
        {
            Log.e(Config.TAG, e.toString());
        }
    }
}
